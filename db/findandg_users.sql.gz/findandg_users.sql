-- MySQL dump 10.15  Distrib 10.0.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: findandg_users
-- ------------------------------------------------------
-- Server version	10.0.31-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `image_url` varchar(200) DEFAULT '0',
  `user_latitude` varchar(50) NOT NULL DEFAULT '0',
  `user_longitude` varchar(50) NOT NULL DEFAULT '0',
  `phone_visibility` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`phone_number`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` (`id`, `name`, `email`, `phone_number`, `gender`, `image_url`, `user_latitude`, `user_longitude`, `phone_visibility`) VALUES (1,'Gaurav Bordoloi','gmonetix@gmail.com','7478870112','MALE','http://www.findandgo.in/server/profile/7478870112.png','26.0245773','89.9742005',1),(2,'Bela Rani Bordoloi','belabordoloi@gmail.com','8486900180','FEMALE','http://www.findandgo.in/server/profile/8486900180.png','26.255333','92.737044',1),(3,'subham kumar','subhamkr@gmail.com','8404017253','MALE','http://www.findandgo.in/server/profile/8404017253.png','26.458005','91.455652',0),(4,'Manish Kumar','mnsh.kumr7@gmail.com','7547041092','MALE','http://www.findandgo.in/server/profile/7547041092.png','26.258235','91.695563',1),(5,'Shekhar Sharma','shekhar@gmail.com','7896541230','MALE','0','23.412953','87.523428',1),(6,'Aniket Dhar','aniketdhar@gmail.com','4563210789','FEMALE','0','24.215456','87.557916',0),(7,'Bijit Das','beatjit@gmail.com','7475362102','MALE','0','26.085831','89.918822',0),(8,'AKash Ghosh','akash@gmail.com','1563240159','MALE','0','26.149918','89.811606',0),(9,'Ronojit DAs','rono@fucker.com','8401593246','MALE','0','26.178615','90.080370',0),(10,'Naveen Prasasd','naveen@gmail.com','7478512364','MALE','0','25.242147','86.638776',0),(11,'KAKHLARI MISRA','misra@misra.com','1254632513','MALE','0','26.417576','90.168192',0);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'findandg_users'
--

--
-- Dumping routines for database 'findandg_users'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-15 19:04:30
